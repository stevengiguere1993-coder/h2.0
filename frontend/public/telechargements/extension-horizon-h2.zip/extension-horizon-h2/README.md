# Horizon h2.0 Helper — Extension navigateur

Extension Chrome/Edge qui scrape automatiquement le rôle d'évaluation
de Montréal (montreal.ca) et les annonces Centris (centris.ca) depuis
ton vrai navigateur, et envoie les données au backend h2.0.

**Pourquoi une extension ?** montreal.ca utilise reCAPTCHA v3 invisible
et Centris utilise Cloudflare/Datadome. Ces protections bloquent les
scrapers automatiques sur VPS mais laissent passer ton vrai navigateur
(qui a une historique Google + IP résidentielle légitime).

## Installation (1 fois, ~2 min)

1. Ouvre Chrome ou Edge
2. Va sur `chrome://extensions/` (ou `edge://extensions/`)
3. Active **Mode développeur** (toggle en haut à droite)
4. Clique **Charger l'extension non empaquetée**
5. Sélectionne le dossier `browser-extension/` de ce repo
6. L'icône Horizon apparaît dans la barre d'extensions

## Configuration (1 fois)

1. Clique sur l'icône Horizon dans la barre d'extensions
2. Remplis :
   - **Backend URL** : `https://h2-0.onrender.com` (production)
     ou `http://localhost:8000` (dev local)
   - **API Key** : récupère-la dans h2.0 → Paramètres → Extension
     (admin uniquement)
3. Clique **Enregistrer** puis **Tester** — tu dois voir « ✅ Connexion OK »

## Utilisation

### Rôle d'évaluation Montréal

1. Va sur https://montreal.ca/role-evaluation-fonciere
2. Cherche ton matricule (Par matricule → 6 sous-champs → Rechercher)
3. Sur la **fiche détaillée** (étape 4 du flow), un toast vert apparaît
   en haut à droite : « ✅ N proprio(s) envoyé(s) à h2.0 »
4. Dans h2.0, ouvre la modale Immeuble MTL pour ce matricule — les
   propriétaires sont déjà là (avec enrichissement REQ + Canada411).

### Configuration automatique (1.2.1)

Plus rien à saisir dans la fenêtre de l'icône : en ouvrant la page
Prospection → Rôles fonciers de Kratos, la page transmet à l'extension
l'adresse du serveur et la clé (`GET /api/v1/extension/config`, utilisateur
connecté). L'extension n'accepte cette configuration que depuis une page
Kratos et vers un serveur Kratos. Corrige « Échec envoi : Backend URL non
configurée » après une réinstallation (2026-09-29).

### Collecte en lot (1.2.0)

1. Dans h2.0 → Prospection → Immeubles MTL, pose tes filtres (ex. 12 à
   24 logements + un arrondissement).
2. Clique **Collecter les propriétaires** : h2.0 envoie à l'extension
   la liste des propriétés SANS propriétaire connu ; un onglet
   montreal.ca s'ouvre en arrière-plan et les traite une par une
   (6 à 11 s chacune, ~400 par heure, plafond 5 000 par lot).
3. Un panneau en bas à droite suit l'avancement : pause, reprise,
   arrêt, « réessayer les échecs ». Après 6 échecs de suite, la
   collecte se met en pause d'elle-même (le site bloque probablement) :
   reprends-la plus tard.
4. Les propriétaires apparaissent dans la liste et dans l'export CSV.
   Garde Chrome ouvert ; l'état survit à un rechargement de la page.

### Centris

1. Navigue sur centris.ca comme d'habitude
2. Sur chaque fiche d'annonce, l'extension détecte et envoie les
   données à h2.0 (toast vert)
3. Si l'annonce est rentable au calculateur, h2.0 crée un lead
   automatiquement avec le tag `centris-interessant`.

### Projets QuickBooks (1.3.0)

Kratos crée un SOUS-CLIENT QuickBooks pour chaque projet, mais Intuit ne
permet pas de le convertir en PROJET par API sans palier partenaire
Silver (Steven, 2026-10-14 : « nous ne serons pas en silver »). La
conversion se fait donc dans le QuickBooks ouvert de la technicienne,
par l'extension :

1. Dans Kratos → Entreprises → Comptabilité → **Projets QB**, la liste
   des sous-clients à convertir (et l'extension se configure toute seule
   en ouvrant la page).
2. Ouvre QuickBooks (compagnie Construction) → **Projets**. Le panneau
   Horizon en bas à droite liste les mêmes sous-clients.
3. **Convertir maintenant** : l'extension ouvre « Nouveau projet ▾ →
   Convertir depuis un sous-client », coche EXACTEMENT les noms attendus
   (jamais « tout sélectionner »), confirme, puis rend compte à Kratos.
   Kratos vérifie ensuite par l'API que le sous-client est bien devenu
   un projet et raye la ligne.
4. Case **Automatique** (désactivée par défaut) : la conversion part
   d'elle-même à l'ouverture de la page Projets, une fois par liste. La
   première fois, regarde-la faire : les écrans de QuickBooks changent.
5. Sans extension : les 4 étapes manuelles restent dans la page Kratos
   et dans le courriel envoyé à la technicienne.

## Côté serveur

Set la variable d'environnement `EXTENSION_API_KEY` sur le backend
(la même valeur que celle entrée dans la popup). Cette clé est
partagée — tous les utilisateurs du browser extension utilisent la
même.

Pour générer une clé sécurisée :

```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

## Endpoints backend

- `POST /api/v1/extension/ping` — test de connexion (requiert
  `X-Extension-Key`)
- `POST /api/v1/extension/evalweb-owners` — reçoit les owners
  scrapés (matricule + owners[])
- `GET /api/v1/extension/evalweb-owners/{matricule}` — frontend polle
  ici (cache TTL 10 min)
- `POST /api/v1/extension/centris-listing` — reçoit une annonce
  Centris (mls_id + détails)
- `GET /api/v1/extension/centris-listing/{mls_id}` — récupère une
  annonce du cache
- `POST /api/v1/extension/qbo-conversions` — sous-clients QuickBooks à
  convertir en projet (noms exacts + compagnie attendue)
- `POST /api/v1/extension/qbo-conversions/resultat` — compte rendu de
  la conversion (`resultats[{project_id, ok, detail}]`) ; Kratos
  constate ensuite par l'API

## Troubleshooting

### Le toast apparaît jamais sur Montréal
- Vérifie que tu es bien sur la fiche détaillée (étape 4 avec
  « 1. Identification de l'unité » + « 2. Propriétaire »)
- Ouvre la console DevTools (F12) → onglet Console → cherche
  `[h2.0 EvalWeb]` pour voir les logs du content script

### « ❌ Backend URL non configurée »
- Clique l'icône extension → re-enregistre la config

### « ❌ HTTP 401 »
- L'API key dans la popup ne match pas `EXTENSION_API_KEY` côté serveur
- Vérifie avec l'admin h2.0 que la clé est la bonne
